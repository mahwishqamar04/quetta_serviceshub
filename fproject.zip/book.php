<?php
$activePage = 'book';
include 'config.php';

$serviceId = isset($_GET['service_id']) ? (int)$_GET['service_id'] : 0;
$message = '';
$messageType = '';

if ($conn) {
    $tableCheck = $conn->query("SHOW TABLES LIKE 'bookings'");
    if ($tableCheck && $tableCheck->num_rows === 0) {
        $conn->query(
            "CREATE TABLE bookings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                service_id INT NOT NULL,
                name VARCHAR(100) NOT NULL,
                phone VARCHAR(30) NOT NULL,
                address TEXT NOT NULL,
                booking_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )"
        );
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceId = isset($_POST['service_id']) ? (int)$_POST['service_id'] : 0;
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $bookingDate = trim($_POST['date'] ?? '');

    if ($serviceId > 0 && $name !== '' && $phone !== '' && $address !== '' && $bookingDate !== '') {
        $stmt = $conn->prepare('INSERT INTO bookings (service_id, name, phone, address, booking_date) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('issss', $serviceId, $name, $phone, $address, $bookingDate);

        if ($stmt->execute()) {
            $message = 'Booking submitted successfully. We will contact you shortly.';
            $messageType = 'success';
        } else {
            $message = 'Unable to save booking. Please try again.';
            $messageType = 'error';
        }

        $stmt->close();
    } else {
        $message = 'Please fill all fields correctly.';
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <header>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom" aria-label="Primary navigation">
        <div class="container-fluid px-3 px-lg-4">
            <a class="navbar-brand" href="index.php">
                <span class="brand-mark"><i class="fa-solid fa-hands-helping"></i></span>
                <span class="brand-text">
                    <span class="brand-name">Quetta Services Hub</span>
                    <span class="brand-tag">Trusted Home Solutions</span>
                </span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php"><i class="fa-solid fa-house"></i> Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php"><i class="fa-solid fa-list-check"></i> Services</a></li>
                    <li class="nav-item"><a class="nav-link <?= $activePage === 'book' ? 'active' : '' ?>" href="book.php"><i class="fa-solid fa-calendar-check"></i> Book</a></li>
                    <li class="nav-item"><a class="nav-link" href="admin_login.php"><i class="fa-solid fa-user-shield"></i> Admin</a></li>
                </ul>
                <a class="btn btn-contact" href="book.php"><i class="fa-solid fa-phone"></i> Contact Us</a>
            </div>
        </div>
    </nav>
    </header>

    <main class="page-shell">
        <div class="page-card page-card--soft page-shell-card page-shell-card--narrow">
            <div class="hero-panel hero-panel--compact">
                <div class="stack-sm">
                    <div class="icon-badge"><i class="fa-solid fa-calendar-day"></i></div>
                    <h2>Book Your Service</h2>
                    <p>Please provide your details and we will reach out to confirm your booking.</p>
                </div>
            </div>

            <?php if ($message !== '') : ?>
                <div class="mb-4 <?= htmlspecialchars($messageType === 'success' ? 'success-banner' : 'error-banner') ?>">
                    <i class="fa-solid <?= htmlspecialchars($messageType === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation') ?>"></i>
                    <span><?= htmlspecialchars($message) ?></span>
                </div>
            <?php endif; ?>

            <div class="row g-4 booking-shell">
                <div class="col-12 col-lg-6">
                    <div class="booking-info-card h-100">
                        <div class="d-flex align-items-center gap-2 mb-3">
                            <span class="icon-badge"><i class="fa-solid fa-star"></i></span>
                            <h4 class="mb-0">Why book with us?</h4>
                        </div>
                        <p class="mb-4" style="color: rgba(255,255,255,0.9);">We make booking simple, fast, and dependable with premium support from start to finish.</p>

                        <div class="info-item">
                            <div class="info-icon"><i class="fa-solid fa-clock"></i></div>
                            <div>
                                <strong>Fast response</strong>
                                <div class="small" style="color: rgba(255,255,255,0.82);">Quick confirmation and clear follow-up.</div>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-icon"><i class="fa-solid fa-shield-halved"></i></div>
                            <div>
                                <strong>Trusted service</strong>
                                <div class="small" style="color: rgba(255,255,255,0.82);">Reliable professionals with a premium experience.</div>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-icon"><i class="fa-solid fa-location-dot"></i></div>
                            <div>
                                <strong>Local support</strong>
                                <div class="small" style="color: rgba(255,255,255,0.82);">Serving clients across Quetta with care and consistency.</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-6">
                    <div class="booking-form-card h-100">
                        <form method="post" class="needs-validation" novalidate>
                            <input type="hidden" name="service_id" value="<?= htmlspecialchars((string)$serviceId) ?>">

                            <div class="form-floating mb-3">
                                <input id="name" name="name" type="text" class="form-control" placeholder="Your full name" required>
                                <label for="name"><i class="fa-solid fa-user me-2"></i> Full Name</label>
                                <div class="invalid-feedback">Please enter your name.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <input id="phone" name="phone" type="tel" class="form-control" placeholder="Phone number" required>
                                <label for="phone"><i class="fa-solid fa-phone me-2"></i> Phone Number</label>
                                <div class="invalid-feedback">Please enter your phone number.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <textarea id="address" name="address" class="form-control" placeholder="Your address" required></textarea>
                                <label for="address"><i class="fa-solid fa-house me-2"></i> Address</label>
                                <div class="invalid-feedback">Please enter your address.</div>
                            </div>

                            <div class="form-floating mb-3">
                                <input id="date" name="date" type="date" class="form-control" required>
                                <label for="date"><i class="fa-solid fa-calendar-days me-2"></i> Preferred Date</label>
                                <div class="invalid-feedback">Please choose a date.</div>
                            </div>

                            <button class="booking-submit" type="submit"><i class="fa-solid fa-paper-plane"></i> Submit Booking</button>
                        </form>

                        <p class="section-subtitle mt-3 mb-0">Service ID: <?= htmlspecialchars((string)$serviceId) ?></p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer-premium" role="contentinfo">
        <div class="container">
            <div class="row g-4">
                <div class="col-12 col-md-6 col-lg-3">
                    <h5 class="footer-title">Company Information</h5>
                    <p class="mb-2">Quetta Services Hub provides reliable, premium home solutions with professionalism and care.</p>
                    <div class="social-links mt-3">
                        <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <h5 class="footer-title">Quick Links</h5>
                    <div class="d-flex flex-column">
                        <a class="footer-link" href="index.php"><i class="fa-solid fa-chevron-right"></i> Home</a>
                        <a class="footer-link" href="book.php"><i class="fa-solid fa-chevron-right"></i> Book Service</a>
                        <a class="footer-link" href="admin_login.php"><i class="fa-solid fa-chevron-right"></i> Admin Login</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <h5 class="footer-title">Services</h5>
                    <div class="d-flex flex-column">
                        <a class="footer-link" href="index.php"><i class="fa-solid fa-screwdriver-wrench"></i> Home Repairs</a>
                        <a class="footer-link" href="index.php"><i class="fa-solid fa-broom"></i> Cleaning</a>
                        <a class="footer-link" href="index.php"><i class="fa-solid fa-plug-circle-bolt"></i> Electrical</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <h5 class="footer-title">Contact Information</h5>
                    <div class="footer-contact">
                        <p><i class="fa-solid fa-envelope"></i> info@quettaserviceshub.com</p>
                        <p><i class="fa-solid fa-phone"></i> +92 300 1234567</p>
                        <p><i class="fa-solid fa-location-dot"></i> Quetta, Balochistan, Pakistan</p>
                    </div>
                </div>
            </div>
            <div class="footer-bottom d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
                <span>© 2026 Quetta Services Hub. All rights reserved.</span>
                <div class="d-flex flex-wrap gap-3">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms</a>
                </div>
            </div>
        </div>
    </footer>

    <a href="#" class="back-to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></a>
</body>
</html>
